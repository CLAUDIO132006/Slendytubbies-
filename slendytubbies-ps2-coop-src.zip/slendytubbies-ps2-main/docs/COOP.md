# Co-op (experimental)

Estado: **sin compilar ni probar en PS2/PCSX2**. El servidor y la logica de
custards compartidos si estan probados en PC. El cliente (`ps2/src/net.c`) usa
ps2ip/netman; si tu PS2SDK difiere, ajusta nombres de funciones segun el error.

## Servidor (PC)
    python server/slendy_server.py --port 7777 --max 4
    python server/test_server.py            # pruebas
.exe para Windows:  pip install pyinstaller ; pyinstaller --onefile server/slendy_server.py
Abre UDP 7777 en el firewall de Windows.

## Cliente (PS2)
1. Copia `NET.CFG.example` como `NET.CFG` junto a `SLENDY.ELF` y edita las IPs
   (IP fija de la PS2, y la IP de la PC con el servidor).
2. Necesitas Network Adapter oficial (o compatible con SMAP) y cable a tu router.
3. Compila como siempre (`bash tools/build_ps2.sh`); el Makefile ya enlaza
   `-lps2ip_nm -lnetman` e incrusta ps2dev9/netman/smap/ps2ip-nm.
4. Menu: Multiplayer > Co-op > elige horario.

## Que hace en v0.1
- Cada PS2 corre su propio Noo-Noo; se sincronizan posiciones de jugadores
  (marcadores de color P1-P4) y los custards recogidos (objetivo compartido).
- Ganan todos cuando entre todos juntan los 10.
- Si mueres o sales al menu, dejas la partida.
- Falta: modelo 3D del companero, enemigo compartido, chat/voz, DHCP.

## Protocolo UDP
Ver cabecera de `server/slendy_server.py`.
