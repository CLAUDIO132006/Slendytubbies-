#!/usr/bin/env python3
"""Slendytubbies PS2 co-op relay server (UDP).

Usage:  python slendy_server.py [--port 7777] [--max 4]
Windows .exe:  pip install pyinstaller && pyinstaller --onefile slendy_server.py

Protocol (little endian). Every packet starts with: 'S' 'T' type id
  1 HELLO   client->server  (header only)
  2 WELCOME server->client  header, id = assigned player id (255 = server full)
  3 STATE   client->server  header + f32 x,y,z,yaw + u8 flags + u8 pad + u16 custard_mask
  4 PEERS   server->client  header(id = receiver) + u8 count + u8 pad + u16 global_mask
                            then count * { u8 id, u8 flags, u16 pad, f32 x,y,z,yaw }
  5 BYE     client->server  (header only)
flags: bit0 flashlight, bit1 crouching, bit2 moving, bit3 dead
"""
import argparse, select, socket, struct, time

MAGIC = b"ST"
HELLO, WELCOME, STATE, PEERS, BYE = 1, 2, 3, 4, 5
TIMEOUT = 5.0
TICK = 1 / 20


class Player:
    __slots__ = ("pid", "addr", "seen", "x", "y", "z", "yaw", "flags", "mask")

    def __init__(self, pid, addr):
        self.pid, self.addr, self.seen = pid, addr, time.time()
        self.x = self.y = self.z = self.yaw = 0.0
        self.flags = 0
        self.mask = 0


def build_peers(players, receiver):
    others = [p for p in players.values() if p.pid != receiver.pid]
    mask = 0
    for p in players.values():
        mask |= p.mask
    out = MAGIC + struct.pack("<BB", PEERS, receiver.pid) + struct.pack("<BBH", len(others), 0, mask)
    for p in others:
        out += struct.pack("<BBHffff", p.pid, p.flags, 0, p.x, p.y, p.z, p.yaw)
    return out


def serve(port, max_players, log=print):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", port))
    sock.setblocking(False)
    players = {}  # addr -> Player
    next_tick = time.time()
    log(f"Slendytubbies co-op server listening on UDP {port} (max {max_players} players)")
    while True:
        wait = max(0, next_tick - time.time())
        ready, _, _ = select.select([sock], [], [], wait)
        if ready:
            try:
                data, addr = sock.recvfrom(512)
            except (BlockingIOError, ConnectionResetError):
                data = b""
            handle(sock, players, max_players, data, addr if data else None, log)
        now = time.time()
        for addr in [a for a, p in players.items() if now - p.seen > TIMEOUT]:
            log(f"player {players[addr].pid} timed out")
            del players[addr]
        if now >= next_tick:
            next_tick = now + TICK
            for p in players.values():
                sock.sendto(build_peers(players, p), p.addr)


def handle(sock, players, max_players, data, addr, log):
    if addr is None or len(data) < 4 or data[:2] != MAGIC:
        return
    kind = data[2]
    p = players.get(addr)
    if kind == HELLO:
        if p is None:
            used = {q.pid for q in players.values()}
            free = [i for i in range(max_players) if i not in used]
            if not free:
                sock.sendto(MAGIC + struct.pack("<BB", WELCOME, 255), addr)
                return
            p = players[addr] = Player(free[0], addr)
            log(f"player {p.pid} joined from {addr[0]}:{addr[1]}")
        p.mask = 0
        p.seen = time.time()
        sock.sendto(MAGIC + struct.pack("<BB", WELCOME, p.pid), addr)
    elif kind == STATE and p is not None and len(data) >= 24:
        p.x, p.y, p.z, p.yaw, p.flags, _, p.mask = struct.unpack_from("<ffffBBH", data, 4)
        p.mask &= 0x3FF
        p.seen = time.time()
    elif kind == BYE and p is not None:
        log(f"player {p.pid} left")
        del players[addr]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=7777)
    ap.add_argument("--max", type=int, default=4, choices=range(2, 5))
    a = ap.parse_args()
    try:
        serve(a.port, a.max)
    except KeyboardInterrupt:
        pass
