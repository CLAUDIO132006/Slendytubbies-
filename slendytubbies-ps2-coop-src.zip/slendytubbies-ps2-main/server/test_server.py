import sys, threading, socket, struct, time
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import slendy_server as s
PORT = 47777
t = threading.Thread(target=s.serve, args=(PORT, 4, lambda *_: None), daemon=True); t.start(); time.sleep(.3)
def client():
    c = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); c.settimeout(1); return c
def send(c, kind, pid=0, body=b""): c.sendto(b"ST" + struct.pack("<BB", kind, pid) + body, ("127.0.0.1", PORT))
a, b = client(), client()
send(a, s.HELLO); ra = a.recv(64); send(b, s.HELLO); rb = b.recv(64)
assert ra[2] == s.WELCOME and rb[2] == s.WELCOME and ra[3] == 0 and rb[3] == 1, (ra, rb)
send(a, s.STATE, 0, struct.pack("<ffffBBH", 1, 2, 3, .5, 5, 0, 0b101))
send(b, s.STATE, 1, struct.pack("<ffffBBH", 9, 8, 7, 1.5, 0, 0, 0b010))
time.sleep(.2)
def last_peers(c):
    pkt = None
    c.settimeout(.2)
    end = time.time() + .3
    while time.time() < end:
        d = c.recv(256)
        if d[2] == s.PEERS: pkt = d
    return pkt
pa, pb = last_peers(a), last_peers(b)
cnt, _, mask = struct.unpack_from("<BBH", pa, 4); assert cnt == 1 and mask == 0b111, (cnt, mask)
pid, fl, _, x, y, z, yaw = struct.unpack_from("<BBHffff", pa, 8); assert pid == 1 and (x, y, z) == (9, 8, 7), (pid, x, y, z)
pid, fl, _, x, y, z, yaw = struct.unpack_from("<BBHffff", pb, 8); assert pid == 0 and fl == 5 and (x, y, z) == (1, 2, 3)
# full server
cs = [client() for _ in range(5)]
for c in cs[2:]: send(c, s.HELLO)
res = []
for c in cs[2:]:
    d = c.recv(64); res.append((d[2], d[3]))
print(res)
res=[r[1] for r in res]; assert res == [2, 3, 255], res
# bye frees slot
send(a, s.BYE); time.sleep(.1); send(cs[4], s.HELLO)
r = cs[4].recv(64); assert r[3] == 0, r
print("SERVER TESTS OK")
