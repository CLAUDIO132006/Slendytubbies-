// Slendytubbies PS2 co-op client (UDP via ps2ip/lwIP). See server/slendy_server.py
// for the wire format. Not part of the original port; MIT like the rest of the code.
#include "net.h"
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <netman.h>
#include <ps2ip.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

extern unsigned char dev9_start[],dev9_end[],netman_start[],netman_end[];
extern unsigned char smap_start[],smap_end[],ps2ipnm_start[],ps2ipnm_end[];

enum { PK_HELLO=1,PK_WELCOME=2,PK_STATE=3,PK_PEERS=4,PK_BYE=5 };
enum { MAX_PEERS=3,SEND_HZ=20 };
typedef struct {char ip[16],mask[16],gateway[16],server[16];int port;int valid;} NetConfig;
static NetConfig cfg;
static int net_ready,net_failed,sock=-1,joined,my_id=255;
static float send_timer,silence;
typedef struct {int used;float x,y,z,yaw;} PeerTarget;
static PeerTarget target[4];

static int parse_ip(const char *s,int out[4]) {
    return sscanf(s,"%d.%d.%d.%d",out,out+1,out+2,out+3)==4;
}
// Must run before SifIopReset: it uses the launcher's mass: driver.
void net_read_config(const char *elf_path) {
    memset(&cfg,0,sizeof(cfg));strcpy(cfg.mask,"255.255.255.0");cfg.port=7777;
    if(!elf_path)return;
    char path[256];strncpy(path,elf_path,sizeof(path)-16);path[sizeof(path)-16]=0;
    char *slash=strrchr(path,'/');if(!slash)slash=strrchr(path,'\\');
    if(slash)strcpy(slash+1,"NET.CFG");
    else if(!strrchr(path,':'))strcpy(path,"NET.CFG");
    else {char *colon=strrchr(path,':');strcpy(colon+1,"NET.CFG");}
    FILE *f=fopen(path,"r");printf("STPS NET cfg %s %s\n",path,f?"found":"missing");
    if(!f)return;
    char line[96];
    while(fgets(line,sizeof(line),f)) {
        char *eq=strchr(line,'=');if(!eq||line[0]=='#')continue;*eq++=0;
        for(char *e=eq;*e;e++)if(*e=='\r'||*e=='\n'||*e==' ')*e=0;
        if(!strcmp(line,"ip"))strncpy(cfg.ip,eq,15);
        else if(!strcmp(line,"netmask"))strncpy(cfg.mask,eq,15);
        else if(!strcmp(line,"gateway"))strncpy(cfg.gateway,eq,15);
        else if(!strcmp(line,"server"))strncpy(cfg.server,eq,15);
        else if(!strcmp(line,"port"))cfg.port=atoi(eq);
    }
    fclose(f);
    int a[4];cfg.valid=parse_ip(cfg.ip,a)&&parse_ip(cfg.server,a)&&cfg.port>0&&cfg.port<65536;
    printf("STPS NET ip=%s server=%s:%d valid=%d\n",cfg.ip,cfg.server,cfg.port,cfg.valid);
}
static int load(void *start,void *end,const char *name) {
    int result=0,id=SifExecModuleBuffer(start,(unsigned char *)end-(unsigned char *)start,0,NULL,&result);
    printf("STPS NET MODULE %s id=%d result=%d\n",name,id,result);return id>=0&&result>=0;
}
static struct sockaddr_in server_addr;
static int net_start(void) {
    if(!cfg.valid)return 0;
    if(!(load(dev9_start,dev9_end,"dev9")&&load(netman_start,netman_end,"netman")&&
         load(smap_start,smap_end,"smap")&&load(ps2ipnm_start,ps2ipnm_end,"ps2ip-nm")))return 0;
    if(NetManInit()<0)return 0;
    int a[4],m[4],g[4]={0,0,0,0};
    parse_ip(cfg.ip,a);parse_ip(cfg.mask,m);if(cfg.gateway[0])parse_ip(cfg.gateway,g);
    ip4_addr_t ip,mask,gw;IP4_ADDR(&ip,a[0],a[1],a[2],a[3]);IP4_ADDR(&mask,m[0],m[1],m[2],m[3]);IP4_ADDR(&gw,g[0],g[1],g[2],g[3]);
    ps2ipInit(&ip,&mask,&gw);
    // Wait up to ~8 s for the Ethernet link (cable + adapter).
    int up=0;for(int i=0;i<80&&!up;i++) {
        up=NetManIoctl(NETMAN_NETIF_IOCTL_ETH_GET_LINK_STATUS,NULL,0,NULL,0)==NETMAN_NETIF_ETH_LINK_STATE_UP;
        if(!up)DelayThread(100*1000);
    }
    printf("STPS NET link=%d\n",up);if(!up)return 0;
    sock=socket(AF_INET,SOCK_DGRAM,0);if(sock<0)return 0;
    int s[4];parse_ip(cfg.server,s);
    memset(&server_addr,0,sizeof(server_addr));server_addr.sin_family=AF_INET;server_addr.sin_len=sizeof(server_addr);
    server_addr.sin_port=htons(cfg.port);server_addr.sin_addr.s_addr=htonl(((unsigned)s[0]<<24)|(s[1]<<16)|(s[2]<<8)|s[3]);
    return 1;
}
static void send_packet(const void *data,int length) {
    sendto(sock,data,length,0,(struct sockaddr *)&server_addr,sizeof(server_addr));
}
static void send_simple(int type) {
    unsigned char p[4]={'S','T',(unsigned char)type,(unsigned char)(my_id&255)};send_packet(p,4);
}
static void send_state(const Game *g) {
    unsigned char p[24];p[0]='S';p[1]='T';p[2]=PK_STATE;p[3]=(unsigned char)my_id;
    float v[4]={g->feet.x,g->feet.y,g->feet.z,g->yaw};memcpy(p+4,v,16);
    p[20]=(unsigned char)((g->flashlight?1:0)|(g->crouching?2:0)|(g->moving?4:0)|(g->state==ST_DEAD?8:0));p[21]=0;
    uint16_t mask=g->custards&0x3FF;memcpy(p+22,&mask,2);send_packet(p,24);
}
static void receive(Game *g,const World *w) {
    unsigned char buf[256];struct sockaddr_in from;
    for(;;) {
        socklen_t length=sizeof(from);
        int n=recvfrom(sock,buf,sizeof(buf),MSG_DONTWAIT,(struct sockaddr *)&from,&length);
        if(n<4)break;
        if(buf[0]!='S'||buf[1]!='T')continue;
        silence=0;
        if(buf[2]==PK_WELCOME)my_id=buf[3];
        else if(buf[2]==PK_PEERS&&n>=8) {
            int count=buf[4];uint16_t mask;memcpy(&mask,buf+6,2);
            if(count>MAX_PEERS||n<8+count*20)continue;
            for(int i=0;i<4;i++)target[i].used=0;
            for(int i=0;i<count;i++) {
                const unsigned char *e=buf+8+i*20;int id=e[0];if(id>3)continue;
                float v[4];memcpy(v,e+4,16);
                int fresh=!target[id].used&&!g->peer[id].active;
                target[id]=(PeerTarget){1,v[0],v[1],v[2],v[3]};
                g->peer[id].flags=e[1];g->peer[id].active=1;
                if(fresh){g->peer[id].feet=(Vec3){v[0],v[1],v[2]};g->peer[id].yaw=v[3];}
            }
            for(int i=0;i<4;i++)if(!target[i].used)g->peer[i].active=0;
            game_coop_merge(g,w,mask);
        }
    }
}
static void leave(Game *g) {
    if(joined){send_simple(PK_BYE);joined=0;}
    my_id=255;memset(g->peer,0,sizeof(g->peer));memset(target,0,sizeof(target));
}
void net_frame(Game *g,const World *w,float dt) {
    if(!g->coop){if(joined)leave(g);return;}
    // Leaving the match (menu) or dying ends the session for this player.
    if(g->state==ST_MENU||g->state==ST_DEAD||g->state==ST_WINSCENE) {leave(g);g->coop=0;return;}
    if(!net_ready&&!net_failed)net_ready=net_start();
    if(!net_ready) {net_failed=1;g->coop=0;g->state=ST_NETWORK;return;}
    if(!joined){memset(target,0,sizeof(target));send_simple(PK_HELLO);joined=1;send_timer=0;silence=0;}
    receive(g,w);
    silence+=dt;
    if(silence>6) {g->coop=0;g->state=ST_NETWORK;leave(g);return;}  // server lost
    send_timer+=dt;
    if(send_timer>=1.f/SEND_HZ) {
        send_timer=0;if(my_id==255)send_simple(PK_HELLO);else send_state(g);
    }
    float k=fminf(1,dt*12);
    for(int i=0;i<4;i++)if(g->peer[i].active&&target[i].used) {
        Vec3 *f=&g->peer[i].feet;f->x+=(target[i].x-f->x)*k;f->y+=(target[i].y-f->y)*k;f->z+=(target[i].z-f->z)*k;
        float d=target[i].yaw-g->peer[i].yaw;while(d>3.14159f)d-=6.28318f;while(d<-3.14159f)d+=6.28318f;
        g->peer[i].yaw+=d*k;
    }
}
