#ifndef SLENDYTUBBIES_NET_H
#define SLENDYTUBBIES_NET_H
#include "game.h"
// Co-op client. Talks UDP to server/slendy_server.py through ps2ip (lwIP).
// Settings come from NET.CFG next to SLENDY.ELF (read before the IOP reset).
void net_read_config(const char *elf_path);
// Call once per frame. Joins/leaves the session as game.coop changes, sends the
// local state at ~20 Hz, applies remote players and shared custards.
void net_frame(Game *game,const World *world,float dt);
#endif
